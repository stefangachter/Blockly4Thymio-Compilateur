# Blockly4Thymio-InterfaceHorsLigne

Interface hors ligne de programmation pour Blockly4Thymio. Basée sur la version 8f54ce1 de Blockly.

Cette interface reprend celle utilisée sur les pages d'exercices du site www.blockly4thymio.net mais elle peu être utilisée sans connexion à internet.

Version du compilateur : 1.2

Blockly4Thymio - © 2015-2017 Okimi (contact at okimi dot net)
